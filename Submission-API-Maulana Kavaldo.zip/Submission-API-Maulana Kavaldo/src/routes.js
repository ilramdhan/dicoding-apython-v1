const {
    addNewBook,
    fetchAllBooks,
    findBookById,
    updateExistingBook,
    removeBook,
} = require('./handler');

const routes = [
    {
        method: 'POST',
        path: '/books',
        handler: addNewBook,
    },
    {
        method: 'GET',
        path: '/books',
        handler: fetchAllBooks,
    },
    {
        method: 'GET',
        path: '/books/{id}',
        handler: findBookById,
    },
    {
        method: 'PUT',
        path: '/books/{id}',
        handler: updateExistingBook,
    },
    {
        method: 'DELETE',
        path: '/books/{id}',
        handler: removeBook,
    },
];

module.exports = routes;
