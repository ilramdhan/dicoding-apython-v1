const { nanoid } = require("nanoid");
const books = require("./books");

const fetchAllBooks = (req, h) => {
  const { name, reading, finished } = req.query;
  let booksFiltered = books;

  if (name !== undefined) {
    booksFiltered = booksFiltered.filter((book) =>
      book.name.toLowerCase().includes(name.toLowerCase())
    );
  } else if (reading !== undefined) {
    booksFiltered = booksFiltered.filter(
      (book) => Number(book.reading) === Number(reading)
    );
  } else if (finished !== undefined) {
    booksFiltered = booksFiltered.filter((book) => book.finished == finished);
  }

  const response = h
    .response({
      status: "success",
      data: {
        books: booksFiltered.map(({ id, name, publisher }) => ({ id, name, publisher })),
      },
    })
    .code(200);

  return response;
};

const findBookById = (req, h) => {
  const { id } = req.params;
  const book = books.find((j) => j.id === id);

  if (book !== undefined) {
    return {
      status: "success",
      data: { book },
    };
  }

  const response = h
    .response({
      status: "fail",
      message: "Buku tidak ditemukan",
    })
    .code(404);

  return response;
};

const addNewBook = (req, h) => {
  const { name, year, author, summary, publisher, pageCount, readPage, reading } = req.payload;

  if (!name) {
    return h
      .response({
        status: "fail",
        message: "Gagal menambahkan buku. Mohon isi nama buku",
      })
      .code(400);
  }

  if (readPage > pageCount) {
    return h
      .response({
        status: "fail",
        message: "Gagal menambahkan buku. readPage tidak boleh lebih besar dari pageCount",
      })
      .code(400);
  }

  const id = nanoid(16);
  const createdAt = new Date().toISOString();
  const updatedAt = createdAt;
  const finished = readPage === pageCount;
  const insertedAt = createdAt;

  const newBook = {
    id,
    name,
    year,
    author,
    summary,
    publisher,
    pageCount,
    readPage,
    finished,
    reading,
    insertedAt,
    updatedAt,
  };

  books.push(newBook);

  const isSuccess = books.some((book) => book.id === id);
  const response = h
    .response({
      status: isSuccess ? "success" : "fail",
      message: isSuccess ? "Buku berhasil ditambahkan" : "Buku gagal ditambahkan",
      data: isSuccess ? { bookId: id } : undefined,
    })
    .code(isSuccess ? 201 : 500);

  return response;
};

const updateExistingBook = (req, h) => {
  const { id } = req.params;
  const index = books.findIndex((book) => book.id === id);

  const { name, year, author, summary, publisher, pageCount, readPage, reading } = req.payload;

  if (!name) {
    return h
      .response({
        status: "fail",
        message: "Gagal memperbarui buku. Mohon isi nama buku",
      })
      .code(400);
  }

  if (readPage > pageCount) {
    return h
      .response({
        status: "fail",
        message: "Gagal memperbarui buku. readPage tidak boleh lebih besar dari pageCount",
      })
      .code(400);
  }

  if (index === -1) {
    return h
      .response({
        status: "fail",
        message: "Gagal memperbarui buku. Id tidak ditemukan",
      })
      .code(404);
  }

  const updatedAt = new Date().toISOString();
  const finished = readPage === pageCount;

  books[index] = { ...books[index], name, year, author, summary, publisher, pageCount, readPage, finished, reading, updatedAt, insertedAt: new Date().toISOString() };

  const response = h
    .response({
      status: "success",
      message: "Buku berhasil diperbarui",
    })
    .code(200);

  return response;
};

const removeBook = (req, h) => {
  const { id } = req.params;
  const index = books.findIndex((book) => book.id === id);

  if (index !== -1) {
    books.splice(index, 1);
    return h
      .response({
        status: "success",
        message: "Buku berhasil dihapus",
      })
      .code(200);
  }

  return h
    .response({
      status: "fail",
      message: "Buku gagal dihapus. Id tidak ditemukan",
    })
    .code(404);
};

module.exports = {
  addNewBook,
  fetchAllBooks,
  findBookById,
  updateExistingBook,
  removeBook,
};