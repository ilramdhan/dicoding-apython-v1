# Dicoding Academy
## Belajar Membuat Aplikasi Back-End untuk Pemula

### Submission Bookshelf API
[11 Oktober 2023]
-- [Dicoding Project](https://github.com/maulanakavaldo/dicoding_project)

Changelog:
- OK
- get book by id
- create addbook, getbook, editbook and removebook handler
- create server


### Run Project

- Run command bellow in project directory
    ```
    npm start
    ```
- Open Postman and send for response

- Stop server
    ```
    CTRL + C
    ```
